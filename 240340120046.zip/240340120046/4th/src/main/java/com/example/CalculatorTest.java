package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.junit.Assert.assertEquals;

public class CalculatorTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        WebDriverManager.chromedriver().clearDriverCache().setup();
        driver = new ChromeDriver();
    }

    @Test
    public void testAddition() {
        // Open the Calculator page
        driver.get("https://testpages.eviltester.com/styled/calculator");

        // Find and interact with web elements
        WebElement number1 = driver.findElement(By.name("number1"));
        WebElement number2 = driver.findElement(By.name("number2"));
        WebElement plusButton = driver.findElement(By.cssSelector("input[value='+']"));
        WebElement resultField = driver.findElement(By.name("result"));

        // Perform the calculation
        number1.sendKeys("5");
        number2.sendKeys("3");
        plusButton.click();

        // Verify the result
        String result = resultField.getAttribute("value");
        assertEquals("8", result);
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}
